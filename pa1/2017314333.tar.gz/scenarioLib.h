#ifndef __SCENARIO_LIB__
#define __SCENARIO_LIB__

#define TRUE		1
#define FALSE		0
#define NON_EXIST	-1

typedef int bool;

void execute(char* filename, char* cmd, int cmdLen);

#endif
