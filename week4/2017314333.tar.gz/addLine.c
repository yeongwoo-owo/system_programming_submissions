#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int addLineNum(int, char*);

int main(int argc, char** argv){
	char c;
	char buf[1000];
	int inputFile=open(argv[1], O_RDONLY);

	char outputTitle[100];
	strcpy(outputTitle, argv[1]);
	strcpy(outputTitle+(strlen(argv[1])-4), "_num.txt");
	int outputFile=open(outputTitle, O_RDWR | O_CREAT | O_TRUNC, 0666);
	
	int lineNum=0;
	int lineLength=addLineNum(++lineNum, buf);

	while(read(inputFile, &c, 1)!=0){
		buf[lineLength++]=c;
		if(c=='\n'){
			write(outputFile, buf, lineLength);
			lineLength=addLineNum(++lineNum, buf);
		}
	}
	
	close(inputFile);
	close(outputFile);
	return 0;
}
